export {environment} from './environment';
export {Angular2cliprojAppComponent} from './angular2cliproj.component';
