import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'angular2cliproj-app',
  templateUrl: 'angular2cliproj.component.html',
  styleUrls: ['angular2cliproj.component.css']
})
export class Angular2cliprojAppComponent {
  title = 'Welcome to Zookeeper!';
}
